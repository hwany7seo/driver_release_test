var PHP_ZTS ="no"
var PHP_DLL_LIB ="php5.lib"
var PHP_DLL ="php5.dll"
var PHP_ANALYZER ="no"
var PHP_PGO ="no"
var PHP_PGI ="no"
var PHP_ALL_SHARED ="no"

