#include "config.w32.h"
#include <php_stdint.h>
#include "win32/php_inttypes.h"
#define TIMELIB_OMIT_STDINT 1
#define TIMELIB_FORCE_LONG32 1
